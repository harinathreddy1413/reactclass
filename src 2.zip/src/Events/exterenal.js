function showAlter() {
    alert("hey hi hari nath");
}