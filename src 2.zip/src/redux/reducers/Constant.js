//constatns
export const GET_NAMES = "GET_NAMES";
export const GET_USERS = "GET_USERS";

