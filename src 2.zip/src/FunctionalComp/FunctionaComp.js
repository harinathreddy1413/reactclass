import React from 'react'

export default function FunctionaComp(props) {
    var x = 10 ;
    var y = 20
    return (
        <div>
            Functional COmponent {props.age}
        </div>
    )
}
