import logo from './logo.svg';
import './App.css';
// import ClassComp from './ClassComp/ClassComp';
// import FunctionaComp from './FunctionalComp/FunctionaComp';
// import LifeCycle from './LifeCycle/LifeCycle';
// import FunctionalHooks from './Hooks/FunctionalHooks';
// import EventFun from './Events/EventFun';
// import EventClass from './Events/EventClass';
// import ListsKeys from './ListsKeys/ListsKeys';
// import Crender from './ConditionalRendering/Crender';
// import Parent from './communication/Parent';
import { BrowserRouter as Router , Route , Routes} from 'react-router-dom';
// import UseMemoHook from './Hooks/UseMemoHook';
// import UseCallbackHook from './Hooks/UseCallbackHook';
// import Formh from './Forms/Formh';
// import { Provider } from 'react-redux';
// import Signup from './Formik/Signup';
// import { store } from './redux/store';
import DemoRedux from './ReduxComponent/DemoRedux';


const details = {name:"harinath ", age:25, place:"hyd"};

function App() {
  return (
    <div className="App">

    
      <Router>
        <Routes>
        {/* <Route  path="/home/:id" element={<ListsKeys></ListsKeys>}></Route>
        <Route  path="/life" element={<LifeCycle></LifeCycle>}></Route>
        <Route exact path="/Crender" element={<Crender></Crender>}></Route>
        <Route exact path="/Parent" element={<Parent></Parent>}></Route>
        <Route path="/usememo" element={<UseMemoHook></UseMemoHook>}>  </Route>
        <Route path="/uc" element={<UseCallbackHook></UseCallbackHook>}>  </Route>
        <Route path="/rfc" element={<Signup></Signup>}>  </Route> */}
        <Route path="/redux" element={<DemoRedux></DemoRedux>}>  </Route>
        <Route path="/*" element={<DemoRedux></DemoRedux>}>  </Route>
        </Routes>
        
      </Router>




      {/* <ClassComp name={details}></ClassComp>
      <FunctionaComp age="25"></FunctionaComp>  */}
      {/* <LifeCycle></LifeCycle> */}
      {/* <FunctionalHooks></FunctionalHooks> */}

      {/* <EventFun></EventFun>
      <EventClass></EventClass> */}
      {/* <Crender></Crender> */}

      {/* <Parent></Parent> */}
home page

      {/* <ListsKeys></ListsKeys> */}
    </div>
  );
}

export default App;

// export default App;
